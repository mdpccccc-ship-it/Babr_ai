import express from 'express';
import OpenAI from 'openai';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = Number(process.env.PORT || 3000);
const model = process.env.OPENAI_MODEL || 'gpt-6-astra';
app.use(express.json({ limit: '15mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function getClient() {
  if (!process.env.OPENAI_API_KEY) {
    const err = new Error('کلید OPENAI_API_KEY روی سرور تنظیم نشده است. فایل .env.example را ببین.');
    err.status = 503;
    throw err;
  }
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}
function textFromResponse(response) {
  if (response.output_text) return response.output_text;
  const parts = [];
  for (const item of (response.output || [])) {
    if (item.type === 'message') for (const c of (item.content || [])) if (c.type === 'output_text') parts.push(c.text);
  }
  return parts.join('\n').trim();
}
app.get('/api/health', (_req, res) => res.json({ status: process.env.OPENAI_API_KEY ? 'configured' : 'missing_api_key', model }));
app.post('/api/chat', async (req, res) => {
  try {
    const client = getClient();
    const message = String(req.body?.message || '').trim();
    const mode = String(req.body?.mode || 'chat');
    if (!message) return res.status(400).json({ error: 'پیام خالی است.' });
    const history = Array.isArray(req.body?.history) ? req.body.history.slice(-12) : [];
    const input = [];
    input.push({ role: 'system', content: 'You are Babr AI (ببر), a helpful Persian-first AI assistant. Reply in the language used by the user, usually Persian. Be accurate, practical, and clearly state uncertainty. Do not claim tools or actions were used unless they were.' });
    for (const item of history) {
      if (!item || !['user', 'assistant'].includes(item.role) || typeof item.content !== 'string') continue;
      input.push({ role: item.role, content: item.content.slice(0, 12000) });
    }
    input.push({ role: 'user', content: message.slice(0, 20000) });
    const params = { model, input };
    if (mode === 'research') params.tools = [{ type: 'web_search' }];
    if (mode === 'reasoning') params.reasoning = { effort: 'high' };
    const response = await client.responses.create(params);
    const reply = textFromResponse(response);
    if (!reply) return res.status(502).json({ error: 'مدل پاسخ متنی برنگرداند.' });
    res.json({ reply, model, mode });
  } catch (err) {
    console.error('chat error:', err?.message || err);
    res.status(err.status || 500).json({ error: err?.message || 'خطای ناشناخته در موتور هوش مصنوعی.' });
  }
});
app.post('/api/image', async (req, res) => {
  try {
    const client = getClient();
    const prompt = String(req.body?.prompt || '').trim();
    if (!prompt) return res.status(400).json({ error: 'توضیح تصویر خالی است.' });
    const response = await client.responses.create({
      model,
      input: `Generate an image from this prompt. Return a generated image: ${prompt.slice(0, 8000)}`,
      tools: [{ type: 'image_generation' }]
    });
    const generated = (response.output || []).find(item => item.type === 'image_generation_call' && item.result);
    if (!generated) return res.status(502).json({ error: 'مدل تصویر تولید نکرد. بررسی کن که حساب API به ابزار image_generation دسترسی داشته باشد.' });
    res.json({ image: `data:image/png;base64,${generated.result}`, model });
  } catch (err) {
    console.error('image error:', err?.message || err);
    res.status(err.status || 500).json({ error: err?.message || 'خطا در تولید تصویر.' });
  }
});
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(port, () => console.log(`Babr AI running on http://localhost:${port} (model: ${model})`));
